<!-- Support questions will not be answered. Use StackExchange or another support channel. -->
<!-- This issue board is for reporting **bugs** and submitting Pull Requests only! -->
