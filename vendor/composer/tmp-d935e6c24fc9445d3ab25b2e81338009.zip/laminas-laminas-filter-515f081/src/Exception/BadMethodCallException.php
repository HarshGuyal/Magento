<?php

declare(strict_types=1);

namespace Laminas\Filter\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
