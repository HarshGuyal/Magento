<?php

declare(strict_types=1);

namespace Laminas\Filter;

/**
 * @deprecated Use DenyList
 */
class Blacklist extends DenyList
{
}
