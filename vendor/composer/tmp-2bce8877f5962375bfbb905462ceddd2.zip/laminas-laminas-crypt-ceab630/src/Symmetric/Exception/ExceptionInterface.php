<?php

namespace Laminas\Crypt\Symmetric\Exception;

use Laminas\Crypt\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
