<?php

namespace Laminas\Crypt\PublicKey\Rsa\Exception;

use Laminas\Crypt\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
