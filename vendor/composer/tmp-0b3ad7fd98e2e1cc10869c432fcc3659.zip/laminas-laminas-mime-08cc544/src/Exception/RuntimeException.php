<?php

namespace Laminas\Mime\Exception;

/**
 * Exception for Laminas\Mime component.
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
