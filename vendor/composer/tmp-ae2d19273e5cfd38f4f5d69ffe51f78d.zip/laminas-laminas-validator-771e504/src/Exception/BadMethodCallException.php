<?php

namespace Laminas\Validator\Exception;

/**
 * @deprecated This file will be removed in 3.0
 *
 * @final
 */
class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
