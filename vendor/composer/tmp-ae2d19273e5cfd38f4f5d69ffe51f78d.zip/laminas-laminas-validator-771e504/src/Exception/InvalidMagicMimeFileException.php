<?php

namespace Laminas\Validator\Exception;

/**
 * @deprecated Since 2.61.0 - This exception will be removed in 3.0
 *
 * @final
 */
class InvalidMagicMimeFileException extends InvalidArgumentException
{
}
