<?php

namespace Laminas\File\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
