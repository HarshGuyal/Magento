<?php

namespace Laminas\File\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
