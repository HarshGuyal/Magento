<?php

namespace Laminas\File\Exception;

/**
 * Exception class raised when invalid arguments are discovered
 */
class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
