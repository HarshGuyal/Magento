<?php

namespace Laminas\File\Exception;

/**
 * Marker interface for exceptions found in this component
 */
interface ExceptionInterface
{
}
