<?php

namespace Laminas\Uri\Exception;

/**
 * Exception for Laminas\Uri
 */
interface ExceptionInterface
{
}
