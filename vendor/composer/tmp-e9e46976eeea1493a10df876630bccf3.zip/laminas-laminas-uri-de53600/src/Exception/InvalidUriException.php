<?php

namespace Laminas\Uri\Exception;

/**
 * Exceptions for Laminas\Uri
 */
class InvalidUriException extends InvalidArgumentException implements ExceptionInterface
{
}
