<?php

namespace Laminas\OAuth\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
