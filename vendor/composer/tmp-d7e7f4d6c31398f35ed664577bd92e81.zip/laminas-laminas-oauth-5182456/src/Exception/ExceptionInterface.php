<?php

namespace Laminas\OAuth\Exception;

interface ExceptionInterface
{
}
