<?php

namespace LaminasTest\OAuth\TestAsset;

use Laminas\OAuth\Token\Request;

class RequestToken39745 extends Request
{
    public function getToken(): string
    {
        return '0987654321';
    }
}
