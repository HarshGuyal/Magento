// Intentional parse error (missing closing parenthesis).
// This should be the only test in this file.
// Testing that the sniff is *not* triggered.

do i++; while (i < 5
