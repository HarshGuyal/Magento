<?php

namespace Laminas\Mail\Header\Exception;

use Laminas\Mail\Exception;

class RuntimeException extends Exception\RuntimeException implements ExceptionInterface
{
}
